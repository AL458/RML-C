%run n subjects and launch data analysis scripts
clear all

cost=3;
RW=4.5;

arg=param_build(RW,cost);

save arg arg

seed=round(rand(1,arg.nsubj)*100000);

for s=1:arg.nsubj
    kenntask_vass(s,arg,seed(s));
end


second_level_an_opt(arg)