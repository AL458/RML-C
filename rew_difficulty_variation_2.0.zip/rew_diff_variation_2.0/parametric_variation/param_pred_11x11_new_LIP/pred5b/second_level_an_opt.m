%group analysis for 2-armed bandid results

function [boostd,LAd,boost,muz]=second_level_an_opt(S,arg)

nstate=size(arg.trans,1);

group=zeros(arg.nsubj,nstate,7);


for s=1:arg.nsubj
    
    
    dat=S{s}; 
    
    buff=cell(3,1);
    
    dat.k(:,1:arg.nexcltri)=[];
    dat.LA(:,1:arg.nexcltri)=[];
    dat.respside(:,1:arg.nexcltri)=[];
    dat.b(:,1:arg.nexcltri)=[];
    
    
    
    for state=1:nstate%1st to 3rd order
        
   
        buff{state}(:,4)=dat.LA(state,dat.k(state,:)>0 & dat.respside(state,:)<3)';%)';
        buff{state}(:,7)=dat.b(state,dat.k(state,:)>0 & dat.respside(state,:)<3)';%)';
        
        group(s,state,4)=mean(buff{state}(:,4));
        group(s,state,7)=mean(buff{state}(:,7));
        
        
        
    end
    
    
end



    boost=squeeze(group(:,3:4,7));%R-r
    LA=squeeze(group(:,3:4,4));%R-r

     muz=mean(LA(:));
%     stdz=std(LA(:));
%     
%     LA=(LA-muz)/stdz;
    
    boostd=mean(boost(:,1)-boost(:,2));
    LAd=mean(LA(:,1)-LA(:,2));
    
    boost=mean(boost(:));
    





