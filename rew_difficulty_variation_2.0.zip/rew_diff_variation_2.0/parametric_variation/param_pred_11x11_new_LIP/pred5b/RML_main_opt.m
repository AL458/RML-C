%run n subjects and launch data analysis scripts

function S=RML_main_opt(arg)

seed=round(rand(1,arg.nsubj)*100000);

S=cell(arg.nsubj,1);

for s=1:arg.nsubj
    S{s}=kenntask_gottl(arg,seed(s));
end
