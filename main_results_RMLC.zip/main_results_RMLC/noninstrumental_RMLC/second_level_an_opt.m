%group analysis for 2-armed bandid results

function second_level_an_opt(arg)

close all

clc

nstate=5;

group=zeros(arg.nsubj,nstate,7);
options=3;
boptions=10;


groupnpr=zeros(arg.nsubj,nstate);
groupnpr2=zeros(arg.nsubj,nstate);
groupnpr3=zeros(arg.nsubj,nstate);
groupnpr4=zeros(arg.nsubj,nstate);
groupnpr5=zeros(arg.nsubj,nstate);

load(['S1']);

grouptr=zeros(arg.nsubj,nstate,length(dat.respside(1,:))-arg.nexcltri);


se=1;

for s=1:arg.nsubj
    
    
    load(['S' num2str(s)]);
    
    buff_npr=cell(3,1);
    buff_npr2=cell(3,1);
    buff_npr3=cell(3,1);
    buff_npr4=cell(3,1);
    buff_npr5=cell(3,1);
    buff=cell(3,1);
    
    dat.H(:,1:arg.nexcltri,:)=[];
    dat.optim(:,1:arg.nexcltri)=[];
    dat.k(:,1:arg.nexcltri)=[];
    dat.D(:,1:arg.nexcltri)=[];
    dat.respside(:,1:arg.nexcltri)=[];
    dat.b(:,1:arg.nexcltri)=[];
    dat.VTA(:,1:arg.nexcltri,:)=[];
    dat.VPI(:,1:arg.nexcltri,:)=[];
    dat.VTA2(:,1:arg.nexcltri,:)=[];
    dat.tritrace(:,1:arg.nexcltri,:)=[];
    
    
    for state=1:nstate%1st to 3rd order
        
%         buff{state}(:,1)=dat.H(state,dat.k(state,:)>0)';
        buff{state}(:,2)=dat.optim(state,dat.k(state,:)>0)';
        buff{state}(:,3)=dat.k(state,dat.k(state,:)>0)';
        buff{state}(:,4)=(abs(dat.D(state,dat.k(state,:)>0)))';
        buff{state}(:,5)=dat.respside(state,dat.k(state,:)>0)';
        buff{state}(:,7)=dat.b(state,dat.k(state,:)>0)';
%         buff{state}(:,8)=squeeze(dat.VTA(state,dat.k(state,1)>0,1)');%VTA policy 1
%         buff{state}(:,9)=squeeze(dat.VTA(state,dat.k(state,2)>0,2)');%VTA policy 2
    
        
        buff_npr{state}=(dat.VTA(state,dat.tritrace(state,:,1)==1,1));
        buff_npr3{state}=(dat.VTA(state,dat.tritrace(state,:,2)==1,2));
        buff_npr5{state}=(dat.H(state,dat.tritrace(state,:,2)==1,2));
        
        if state<4
            buff_npr2{state}=(dat.VPI(state,:,1));
            buff_npr4{state}=(dat.VPI(state,:,2));
            
            groupnpr2(s,state)=squeeze(mean(buff_npr2{state}));
            groupnpr4(s,state)=squeeze(mean(buff_npr4{state}));
        end
        
        
        group(s,state,1)=mean(buff{state}(:,1));
        group(s,state,2)=mean(buff{state}(buff{state}(:,2)~=.5,2));%exclude "stay" trials
        group(s,state,3)=mean(buff{state}(:,3));
        group(s,state,5)=mean(buff{state}(buff{state}(:,5)<3 & buff{state}(:,5)>0,5));%exclude "stay" trials
        group(s,state,7)=mean(buff{state}(:,7));
%         group(s,state,8)=mean(buff{state}(:,8));
%         group(s,state,9)=mean(buff{state}(:,9));
        
        if sum(arg.trans(1,:))>4 || sum(arg.trans(1,:))>6%if Gersch et al. 2015 task
           grouptr(s,state,:)=dat.optim(state,:);
        end
        
        groupnpr(s,state)=squeeze(mean(buff_npr{state}));
        groupnpr3(s,state)=squeeze(mean(buff_npr3{state}));
        groupnpr5(s,state)=squeeze(mean(buff_npr5{state}));
        
    end
    

%     groupnpr3(s,:,:)=squeeze(mean(dat.V(:,arg.nexcltri+1:end,:),2));
%     groupnpr2(s,:,:)=squeeze(mean(dat.V2(:,arg.nexcltri+1:end,:),2));
    
end


boost=squeeze(group(:,1:3,7));
res=squeeze(group(:,1:3,5));
%VTA for policy 1 (uncover)
% VTA(:,1)=squeeze(sum(groupnpr(:,[1,4]),2));
% VTA(:,2)=squeeze(groupnpr(:,[2])+mean(groupnpr(:,[4,5]),2));
% VTA(:,3)=squeeze(sum(groupnpr(:,[3,5]),2));
VTA(:,1)=squeeze(sum(groupnpr(:,[1]),2));
VTA(:,2)=squeeze(sum(groupnpr(:,[2]),2));
VTA(:,3)=squeeze(sum(groupnpr(:,[3]),2));


%VTA for policy 2 (stay)
VTA2(:,1)=squeeze(sum(groupnpr3(:,[1]),2));
VTA2(:,2)=squeeze(sum(groupnpr3(:,[2]),2));
VTA2(:,3)=squeeze(sum(groupnpr3(:,[3]),2));

%H for policy 2 (stay)
H(:,1)=squeeze(sum(groupnpr5(:,[1]),2));
H(:,2)=squeeze(sum(groupnpr5(:,[2]),2));
H(:,3)=squeeze(sum(groupnpr5(:,[3]),2));
H(isnan(H(:,1)),1)=0;

%VPI for policy 1 (uncover)
VPI(:,1)=squeeze(sum(groupnpr2(:,[1,4]),2));
VPI(:,2)=squeeze(sum(groupnpr2(:,[2,4,5]),2));
VPI(:,3)=squeeze(sum(groupnpr2(:,[3,5]),2));

%VPI for policy 2 (stay)
VPI2(:,1)=squeeze(sum(groupnpr4(:,[1]),2));
VPI2(:,2)=squeeze(sum(groupnpr4(:,[2]),2));
VPI2(:,3)=squeeze(sum(groupnpr4(:,[3]),2));

disp('Boost stats ------------------------')
[p,table]=anova_rm(boost)
[h,p,ci,t]=ttest(boost(:,2),boost(:,1))
disp(' ')

disp('Behav stats ------------------------')
[p,table]=anova_rm(res)
[h,p,ci,t]=ttest(res(:,1),res(:,2))
disp(' ')

disp('VTA stats --------------------------')
[p,table]=anova_rm(VTA)
[h,p,ci,t]=ttest(VTA(:,1),VTA(:,2))
disp(' ')


disp('H value for stay policy --------------------------')
disp(['H = ' num2str(mean(H,1))]);
disp(' ')


% disp('VTA2 stats -------------------------')
% [p,table]=anova_rm(VTA2)



% plot_res(1:3, mean(VTA,1), std(VTA,1)/size(VTA,1).^.5, ['VTA (a.u.)']);
% 
% plot_res(1:3, mean(VTA2,1), std(VTA2,1)/size(VTA2,1).^.5, ['VTA2 (a.u.)']);
% figure
% 
close all
VTAglobal=[VTA;VTA2];
mu=mean(VTAglobal(:));
sigma=std(VTAglobal(:));
errnorm=size(VTA,1).^.5;
VTAz=(VTA-mu)/sigma;
VTA2z=(VTA2-mu)/sigma;
VTA_bar=[mean(VTAz(:,1)) mean(VTA2z(:,1));mean(VTAz(:,2)) mean(VTA2z(:,2));mean(VTAz(:,3)) mean(VTA2z(:,3))];
VTA_err=[std(VTAz(:,1)) std(VTA2z(:,1));mean(VTAz(:,2)) mean(VTA2z(:,2));mean(VTAz(:,3)) mean(VTA2z(:,3))]./errnorm;
% barwitherr(VTA_err, VTA_bar);

figure
VPIglobal=[VPI;VPI2];
mu=mean(VPIglobal(:));
sigma=std(VPIglobal(:));
errnorm=size(VPI,1).^.5;
VPIz=VPI;%(VPI-mu)/sigma;
VPI2z=VPI2;%(VPI2-mu)/sigma;
VPIdiff=VPI-VPI2;
VPI_bar=[mean(VPIz(:,1)) mean(VPI2z(:,1));mean(VPIz(:,2)) mean(VPI2z(:,2));mean(VPIz(:,3)) mean(VPI2z(:,3))]
VPI_err=[std(VPIz(:,1)) std(VPI2z(:,1));mean(VPIz(:,2)) mean(VPI2z(:,2));mean(VPIz(:,3)) mean(VPI2z(:,3))]./errnorm;
barwitherr(VPI_err, VPI_bar);

plot_res(1:3, 100*mean(2-res,1), 100*std(2-res,1)/size(res,1).^.5, ['Uncover (%)']);

uncover=[2-res];

mu=mean(boost(:));
sigma=std(boost(:));
% boost=(boost-mu)/sigma;
plot_res(1:3, mean(boost,1), std(boost,1)/size(boost,1).^.5, ['Cat Boost (a.u.)']);



VTAdiff=VTA;
mu=mean(VTAdiff(:));
sigma=std(VTAdiff(:));
VTAd=(VTAdiff-mu)/sigma;
plot_res(1:3, mean(VTAd,1), std(VTAd,1)/size(boost,1).^.5, ['VTA (Z-scored)']);

plot_res(1:3, mean(VTAdiff,1), std(VTAdiff,1)/size(boost,1).^.5, ['VTA uncover>stay (a.u.)']);


% We=squeeze(mean(groupnpr2,1));
% W=squeeze(mean(groupnpr3,1));
% 
% save('W','W');
% save('We','We');
save VTA VTA
save uncover uncover
save boost boost
save VPI VPI
save VPIdiff VPIdiff


