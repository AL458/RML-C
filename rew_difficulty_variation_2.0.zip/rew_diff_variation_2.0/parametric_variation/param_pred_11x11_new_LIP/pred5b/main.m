%main cript for grid search on hors-gottleb task performed by the RML

function [boostd,LAd,boost,LA]=main(RW,diff)



arg = param_build(RW,diff);

S=RML_main_opt(arg);

[boostd,LAd,boost,LA]=second_level_an_opt(S,arg);




