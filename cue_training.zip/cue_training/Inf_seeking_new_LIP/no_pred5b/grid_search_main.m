%main cript for grid search on hors-gottleb task performed by the RML

clear all
 clc

% RW=[1 2 3];
% THS=[0.0000001 0.0000004];
RW=[4,2];%[2,1;3,1.5;4,2];
THS=[0.0000015];%[0.00000001 0.0000001 0.0000006];


%  THS=[2 3 4 5];

Ncycl=length(RW)*length(THS);

dat=zeros(8,Ncycl);
d=zeros(length(THS),length(RW));
t=1;

disp([num2str(0/Ncycl*100) '%'])

for rw=1:size(RW,1)
    for ths=THS
        
        arg = param_build(RW(rw,:),ths);
        
        RML_main_opt(arg);
        
        [boost,opt]=second_level_an_opt(arg);
        
        dat(:,t)=[RW(rw,:),ths,boost',opt];
        
        clc
        disp([num2str(t/Ncycl*100) '%'])
        disp(num2str(dat))
        
        t=t+1;
    end
end

save dat dat

% %plot boost surface
% for i=1:length(THS)
%     d(i,:)=dat(3,dat(2,:)==THS(i));
% end
% 
% surf(d)
% xlabel('Reward level');
% ylabel('Difficulty level')
% zlabel('LC activity')


