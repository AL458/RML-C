%write down parameters data structure from Gersch et al., 2015

function arg = param_build(RWM,THS)

arg.nsubj=30;
arg.initstate=1;
arg.nexcltri=70;
arg.nactions=3;%numb of possible actions by dACC_Action
arg.nactions_boost=10;%numb of possible actions by dACC_Boost

cost=0.2;

arg.punish=0; %in case of error, punishment is x% of primary reward magnitude

arg.pred=2;%defines whether dots cloud is a predictive cue (only for Gottlieb's study); 2=pred, 0=nopred;

arg.speed=40; %absolute value of dots motion speed
arg.cuepos=40; %absolute value of dots position in head-centered space

arg.ths=THS;%0.0002;%linear attractor parameters
arg.LAmult=0.0009;
arg.LAbsl=3;

arg.HR=RWM(1);%HR magnitude
arg.LR=RWM(2);%LR magnitude

arg.volnum=[14,22];%min and max trials before a change point in volatility task (SE=3)

%reward mean magnitude and variance by SE
arg.RWM=[0 0 0 0 0 0;...
         0 0 0 0 0 0;...
         RWM(1) RWM(1) 0 0 0 0;...
         RWM(2) RWM(2) 0 0 0 0];
arg.var=[0 0 0 0 0 0;...
         0 0 0 0 0 0;...
         0.0 0.0 0 0 0 0;...
         0.0 0.0 0 0 0 0];
     %state-action transitions (4=end of trial)
arg.trans=[3 3;...
           4 4;...
           5 5;...
           5 5;];
%reward prob by SE
arg.RWP=[1 1 .0 .0 .0 .0;... %reward rates at dfferent cond order
	     1 1 .0 .0 .0 .0;...
         1 0 0 0 0 0;...
         1 0 0 0 0 0];
 
 %number of statistical environments administered
arg.SEN=[1 1 1];%SE*REPS;
arg.chance=0.5;%specify what is the a priori chance level to execute the task optimally
arg.chance2=0;%specify what is the a priori chance level to execute the task optimally 
%(if prob is referred to completing the task, then 0, otherwise it refers to the prob of answering correclty to each state within a trial)

arg.constAct.temp=0.6;%temperature
arg.constAct.k=0.3;%initial kalman gain;
arg.constAct.mu=0.1;
arg.constAct.omega=0;
arg.constAct.alpha=0.3;
arg.constAct.eta=0.15;
arg.constAct.beta=1;
arg.constAct.gamma=0.1;
arg.constAct.classic=0;

arg.constAct.lesion=1;%DA lesion, 1=no lesion;

arg.constAct.costs=[cost cost 0
                    cost cost 0
                    cost cost 0
                    cost cost 0];
arg.constAct.nstate=max(max(arg.trans))-1;
arg.constBoost=arg.constAct;
arg.constBoost.costs=zeros(arg.constAct.nstate,arg.nactions_boost);
arg.constBoost.temp=0.3;
arg.constBoost.omega=0.15;

%init value weights
W3=zeros(arg.constAct.nstate,arg.nactions);
We3=zeros(arg.constAct.nstate,arg.nactions_boost);

