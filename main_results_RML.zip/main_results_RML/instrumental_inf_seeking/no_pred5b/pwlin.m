%this function calculates the output of a vector of neurons with psp stored in x
function [out] = pwlin(x,a,b)

   x((x-b)<=0)=0;
   
   out=a*x;
    
