

rew=[2.4 1.2
     2.6 1.3
     2.8 1.4
     3   1.5
     3.2 1.6
     3.4 1.7
     3.6 1.8
     3.8 1.9
     4 2
     4.2 2.1
     4.4 2.2];
     
 diff=sort([20:2:40],'descend');

% diff=[8 3]*10^-4;

% diff=[7 6].^5;

 
 Inf_delta_b=zeros(length(rew),length(diff));
%  UnInf_delta_b=zeros(length(rew),length(diff));
 Inf_delta_LA=zeros(length(rew),length(diff));
%  UnInf_delta_LA=zeros(length(rew),length(diff));

 Inf_b=zeros(length(rew),length(diff));
%  UnInf_b=zeros(length(rew),length(diff));
 Inf_LA=zeros(length(rew),length(diff));
%  UnInf_LA=zeros(length(rew),length(diff));
 
 Ncycl=length(rew)*length(diff);
 N=1;

 cd pred5b
 
for r=1:length(rew)
    for d=1:length(diff)
        
%         
        
        [Inf_delta_b(r,d),Inf_delta_LA(r,d),Inf_b(r,d),Inf_LA(r,d)]=main(rew(r,:),diff(d));
        
        clc
        disp([num2str(100*N/Ncycl) '%'])
        
        N=N+1;
        
    end
end

cd ..

save Inf_delta_b Inf_delta_b
% save UnInf_delta_b UnInf_delta_b

save Inf_delta_LA Inf_delta_LA
% save UnInf_delta_LA UnInf_delta_LA

save Inf_b Inf_b
% save UnInf_delta_b UnInf_delta_b

save Inf_LA Inf_LA

figure
surf(Inf_delta_b); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
title('Boost delta Inf')
ylabel('aver rew')
xlabel('difficulty')
zlabel('R>r')

figure
surf(Inf_b); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
title('Boost Inf')
ylabel('aver rew')
xlabel('difficulty')
zlabel('average b')

figure
surf(Inf_LA); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
title('LIP Inf')
ylabel('aver rew')
xlabel('difficulty')
zlabel('activity')

% figure
% surf(UnInf_delta_b); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
% title('Boost UnInf')
% ylabel('aver rew')
% xlabel('difficulty')
% zlabel('R>r')

figure
surf(Inf_delta_LA); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
title('LIP delta Inf')
ylabel('aver rew')
xlabel('difficulty')
zlabel('R>r')

% figure
% surf(UnInf_delta_LA); yticklabels(mat2cell(mean(rew,2)',1,length(rew)));xticklabels(mat2cell([1:length(diff)],1,length(diff)));
% title('LIP UnInf')
% ylabel('aver rew')
% xlabel('difficulty')
% zlabel('R>r')



