%group analysis for 2-armed bandid results

function [boost,opt]=second_level_an_opt(arg)

nstate=size(arg.trans,1);

group=zeros(arg.nsubj,nstate,7);
options=3;
boptions=10;
% boost=zeros(arg.nsubj,2);
% stay=zeros(arg.nsubj,2);

groupnpr=zeros(arg.nsubj,nstate);
groupnpr3=zeros(arg.nsubj,nstate,options);
groupnpr2=zeros(arg.nsubj,nstate,boptions);
groupnpr4=zeros(arg.nsubj,nstate);

load(['S1']);


grouptr=zeros(arg.nsubj,nstate,length(dat.respside(1,:))-arg.nexcltri);


se=1;

for s=1:arg.nsubj
    
    
    load(['S' num2str(s)]);
    
    
    buff_npr=cell(3,1);
    
    buff_npr3=cell(3,1);
    buff=cell(3,1);
    
    dat.rw(:,1:arg.nexcltri)=[];
    dat.optim(:,1:arg.nexcltri)=[];
    dat.k(:,1:arg.nexcltri)=[];
    dat.D(:,1:arg.nexcltri)=[];
    dat.respside(:,1:arg.nexcltri)=[];
    dat.b(:,1:arg.nexcltri)=[];
    dat.VTA(:,1:arg.nexcltri)=[];
    dat.VTA2(:,1:arg.nexcltri)=[];
    
    
    
    for state=1:nstate%1st to 3rd order
        
        buff{state}(:,1)=dat.rw(state,dat.k(state,:)>0)';
        buff{state}(:,2)=dat.optim(state,dat.k(state,:)>0)';
        buff{state}(:,3)=dat.k(state,dat.k(state,:)>0)';
        buff{state}(:,4)=dat.D(state,dat.k(state,:)>0)';
        buff{state}(:,5)=dat.respside(state,dat.k(state,:)>0)';
        buff{state}(:,7)=dat.b(state,dat.k(state,:)>0)';
        
        ntri=length(buff{state});%number of trials
        
        buff_npr{state}=(dat.VTA(state,dat.VTA(state,:)>0));
        buff_npr3{state}=(dat.VTA2(state,dat.VTA2(state,:)>0));
        
        
        group(s,state,1)=mean(buff{state}(:,1));
        group(s,state,2)=mean(buff{state}(buff{state}(:,5)~=3,2));%exclude "stay" trials
        group(s,state,3)=mean(buff{state}(:,3));
        
        bufft=zeros(ntri,1);
        
        for tri=1:ntri
            if state<3 && buff{state}(tri,5)==3
                bufft(tri)=1;
            else
                bufft(tri)=0;
            end
        end
        
        group(s,state,5)=mean(bufft);%record all resp
        group(s,state,4)=mean(buff{state}(:,4));
        group(s,state,7)=mean(buff{state}(:,7));
        
        if sum(arg.trans(1,:))>4 || sum(arg.trans(1,:))>6%if Gersch et al. 2015 task
           grouptr(s,state,:)=dat.optim(state,:);
        end
        
        groupnpr(s,state)=mean(buff_npr{state});
        groupnpr4(s,state)=mean(buff_npr3{state});
        
    end
    
    groupnpr3(s,:,:)=squeeze(mean(dat.V(:,arg.nexcltri+1:end,:),2));
    groupnpr2(s,:,:)=squeeze(mean(dat.V2(:,arg.nexcltri+1:end,:),2));
    
end



    boost=squeeze(group(:,3:4,7));
    LA=squeeze(group(:,3:4,4));
    stay=squeeze(group(:,1:2,5));

opt=squeeze(group(:,3:4,2));




We=squeeze(mean(groupnpr2,1));
W=squeeze(mean(groupnpr3,1));

save('NE','boost');
save('stay','stay');
save('opt','opt');
save('LA','LA');


save('W','W');
save('We','We');


