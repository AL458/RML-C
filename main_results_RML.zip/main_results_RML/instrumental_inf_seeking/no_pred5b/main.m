%main cript for grid search on hors-gottleb task performed by the RML

clear all
 clc

RW=[2.4,1.4];%HR and LR
THS=0;%[0.0000005];%dots motion detection threshold



%  THS=[2 3 4 5];

Ncycl=length(RW)*length(THS);

dat=zeros(4,Ncycl);
d=zeros(length(THS),length(RW));

disp([num2str(0/Ncycl*100) '%'])

arg = param_build(RW,THS);

RML_main_opt(arg);

[boost,opt]=second_level_an_opt(arg);




