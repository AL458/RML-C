
cd pred5b_100

main;

cd ..

cd no_pred5b_100

main;

cd ..
% cd no_pred5b_rand
% 
% main;
% 
% cd ..

% 
