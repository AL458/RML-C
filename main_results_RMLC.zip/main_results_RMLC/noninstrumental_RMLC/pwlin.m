%this function calculates the output of a vector of neurons with psp stored in x
function [out] = pwlin(x,a,b)
N=max(size(x));
out=zeros(size(x,1),size(x,2));
%x=x-b;
for i=1:N
    if(x(i)>b)
        out(i)=a.*x(i);
    else
        out(i)=0;
    end
end