%run n subjects and launch data analysis scripts

function RML_main_opt(arg)

seed=round(rand(1,arg.nsubj)*100000);

for s=1:arg.nsubj
    kenntask_gottl(s,arg,seed(s));
end
